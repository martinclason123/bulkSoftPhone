const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const csvtojson = require("csvtojson");
let csvWrite = [];

const csvWriter = createCsvWriter({
  path: 'convertedEmails.csv',
  header: [
      {id: 'email', title: 'EMAIL ADDRESS'},       
  ]
});

csvtojson()
.fromFile('SoftphoneResponses.csv')
.then(csvData =>{
    for (var i = 0; i < csvData.length; i++) {
        
        entry = {
                 email : `${csvData[i].networkUsername}@grand-rapids.mi.us`
               };

        csvWrite.push(entry);


       }   
     
     csvWriter.writeRecords(csvWrite)       // returns a promise
     .then(() => {
     console.log('...Done');
 });

})