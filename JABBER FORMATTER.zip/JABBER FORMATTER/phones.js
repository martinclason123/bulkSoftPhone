

const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const csvtojson = require("csvtojson");

const csvWriter = createCsvWriter({
  path: 'convertedPhones.csv',
  header: [
      {id: 'deviceName', title: 'Device Name'},
      {id: 'userName', title: 'Owner User ID'},      
      {id: 'description', title: 'Description'},
      {id: 'directoryNumber', title: 'Directory Number 1'},
      {id: 'display1', title: 'Display 1'},
      {id: 'ASCIIdisplay1', title: 'ASCII Display 1'},    
  ]
});

let csvWrite = [];

  csvtojson()
   .fromFile('SoftphoneResponses.csv')
   .then(csvData =>{
       for (var i = 0; i < csvData.length; i++) {
           entry = {deviceName : `CSF${csvData[i].networkUsername}`, userName : csvData[i].networkUsername, 
                    description : `${csvData[i].firstName} ${csvData[i].lastName} Jabber`, 
                    directoryNumber : csvData[i].Extension,
                    display1 : `${csvData[i].firstName} ${csvData[i].lastName}`,
                    ASCIIdisplay1 : `${csvData[i].firstName} ${csvData[i].lastName} ${csvData[i].Extension}` 
                  };

           csvWrite.push(entry);


          }   
  
        csvWriter.writeRecords(csvWrite)       // returns a promise
        .then(() => {
        console.log('...Done');
    });
})


