To convert data to softphone format, dave a CSV in this folder named 'softphoneResponses.csv'

The CSV should use the following format:

firstName,lastName,networkUsername,Extension
John,Doe,jdoe,1234

From the terminal, use the following commands:

node users.js
node phones.js
nodes emails.js

Upload the CSV files to the CUCM Bulk Administrator Tool


