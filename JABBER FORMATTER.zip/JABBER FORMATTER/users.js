const createCsvWriter = require('csv-writer').createObjectCsvWriter;
const csvtojson = require("csvtojson");
let csvWrite = [];

const csvWriter = createCsvWriter({
  path: 'convertedUsers.csv',
  header: [
      {id: 'userName', title: 'USER ID'},      
      {id: 'cti', title: 'ALLOW CONTROL OF DEVICE FROM CTI'},
      {id: 'mobility', title: 'ENABLE MOBILITY'},
      {id: 'access1', title: 'ACCESS CONTROL GROUP 1'},
      {id: 'access2', title: 'ACCESS CONTROL GROUP 2'},    
  ]
});

csvtojson()
.fromFile('SoftphoneResponses.csv')
.then(csvData =>{
    for (var i = 0; i < csvData.length; i++) {
        
        entry = {
                 userName : csvData[i].networkUsername, 
                 cti : `t`, 
                 mobility : 't',
                 access1 : 'Standard CTI Enabled',
                 access2 : 'Standard CCM End Users'
               };

        csvWrite.push(entry);


       }   
     
     csvWriter.writeRecords(csvWrite)       // returns a promise
     .then(() => {
     console.log('...Done');
 });

})